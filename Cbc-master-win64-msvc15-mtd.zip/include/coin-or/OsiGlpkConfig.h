/* src/OsiGlpk/config_osiglpk.h.  Generated from config_osiglpk.h.in by configure.  */
/* src/Osi/config_osiglpk.h.in. */

#ifndef __CONFIG_OSIGLPK_H__
#define __CONFIG_OSIGLPK_H__

/* Library Visibility Attribute */
#define OSIGLPKLIB_EXPORT 

#endif
