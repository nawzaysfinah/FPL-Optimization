/* src/OsiCbc/config_osicbc.h.  Generated from config_osicbc.h.in by configure.  */
/* src/config_osicbc.h.in. */

#ifndef __CONFIG_OSICBC_H__
#define __CONFIG_OSICBC_H__

/* Library Visibility Attribute */
#define OSICBCLIB_EXPORT 

#endif
